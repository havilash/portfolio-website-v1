package com.example.havilash_sivaratnam_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HavilashSivaratnamBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HavilashSivaratnamBackendApplication.class, args);
	}

}
