package com.example.havilash_sivaratnam_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HavilashSivaratnamBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
